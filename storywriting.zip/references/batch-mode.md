# Batch Mode — Phased Pipeline

Use this file for every batch of 2+ concepts. **Never one-shot a full batch in a single session.**

---

## Session limits (hard rules)

| Phase | Max items/session | Why |
|-------|-------------------|-----|
| 0 — Plan | 10 | Outline only, lightweight |
| 1 — Photo prompt | 5 | Keep character/setting consistency |
| 2 — Caption | 5 | Must match photo prompts |
| 3 — Full story | **2** | Heaviest stage (~7k chars each) |
| 4 — Export TXT | 1 batch | Format only, no creative writing |

**One session = one phase only.** Stop after each phase. Wait for user confirmation before the next.

---

## File layout per batch

```
output/{batch-id}/
  {batch-id}-plan.md       ← Phase 0
  {batch-id}.json          ← Phases 1–3 (source of truth)
  {batch-id}-package.txt   ← Phase 4 (assembled from JSON)
  {batch-id}-photos.txt    ← optional split export
  {batch-id}-captions.txt
  {batch-id}-stories.txt
```

---

## JSON schema

```json
{
  "batchId": "batch-04",
  "prefix": "C041",
  "conceptSource": "concepts2 / Concept 03",
  "items": [
    {
      "id": "C041",
      "title": "Humiliation phrase → Reveal phrase",
      "conceptSource": "Concept 03 #7",
      "openingStyle": "Silent witness",
      "characterBible": "CHARACTER LOCK — do not change...",
      "photoPrompt": null,
      "caption": null,
      "fullStory": null,
      "status": {
        "plan": true,
        "photo": false,
        "caption": false,
        "story": false
      }
    }
  ]
}
```

**Rules:**
- Create JSON skeleton in Phase 0 with `characterBible`, beats, and metadata filled
- Each later phase **updates only its fields** — never rewrite completed items unless user asks
- Set `status.*` to `true` when that field is done

---

## TXT package format (Phase 4)

```text
# BATCH-04 | C041–C050 | concepts2 Concept 03

================================================================================
C041 | Intern Blocked → Founder Security Guard
================================================================================

[CHARACTER LOCK]
...

[PHOTO PROMPT]
...

[CAPTION — 1124 chars]
...

[FULL STORY — 6847 chars]
...
```

Separator between items: 80 equals signs.

Split files use `---` between items (same as old "Copy All" blocks).

---

## Copy-paste prompts (replace placeholders)

Placeholders: `{BATCH_ID}`, `{IDS}`, `{ID_A}`, `{ID_B}`, `{CONCEPT_SOURCE}`, `{COUNT}`

### Master — start a new batch

```
Dùng skill storywriting — BATCH MODE.

Batch: {BATCH_ID}
Items: {COUNT} ({IDS})
Concept source: {CONCEPT_SOURCE}

Workflow bắt buộc — mỗi phase = 1 session riêng:
  Phase 0 → plan.md + JSON skeleton
  Phase 1 → photo prompts (5+5 nếu 10 items)
  Phase 2 → captions (5+5)
  Phase 3 → full stories (2/lần)
  Phase 4 → package.txt từ JSON

KHÔNG one-shot. KHÔNG HTML. Deliverable cuối: {BATCH_ID}-package.txt

Bắt đầu Phase 0 ONLY. Dừng sau khi xong, chờ tôi confirm.
```

---

### Phase 0 — Story Plan

```
Dùng skill storywriting — Phase 0 ONLY.

Batch: {BATCH_ID} | Items: {IDS} | Source: {CONCEPT_SOURCE}

Đọc concept bank tương ứng (concepts1 hoặc concepts2).

Tạo STORY PLAN — KHÔNG viết photo prompt, caption, full story, txt.

Mỗi item gồm:
- id | title (humiliation → reveal)
- conceptSource
- 4-beat arc (Setup / Clue / Turn / Payoff) — 1–2 câu/beat
- Character Lock đầy đủ (protagonist, antagonist, setting US, object clue)
- Peak-tension moment cho photo (Beat 1–2, không spoil twist)
- openingStyle (1 trong 10 styles, không trùng liên tiếp)

Output:
1. output/{BATCH_ID}/{BATCH_ID}-plan.md
2. output/{BATCH_ID}/{BATCH_ID}.json — skeleton với characterBible + status.plan=true

Rotate location, twist type, opening style across items.
DỪNG sau Phase 0. Không làm Phase 1.
```

---

### Phase 1A — Photo Prompts (first half)

```
Dùng skill storywriting — Phase 1A ONLY.

Đọc references/nano-banana-2.md
Đọc output/{BATCH_ID}/{BATCH_ID}-plan.md
Đọc output/{BATCH_ID}/{BATCH_ID}.json

Viết PHOTO PROMPT cho {IDS} (nửa đầu batch).
- Mở đầu: 4:5 vertical + smartphone snapshot aesthetic
- Character Lock khớp plan/JSON
- Peak tension Beat 1–2, twist KHÔNG được vẽ
- Không readable text in scene

Cập nhật {BATCH_ID}.json — chỉ photoPrompt + status.photo=true cho items này.
KHÔNG viết caption, story, txt.
DỪNG sau Phase 1A.
```

**Phase 1B** — same prompt, second half of IDs.

---

### Phase 2A — Captions (first half)

```
Dùng skill storywriting — Phase 2A ONLY.

Đọc references/caption-methodology.md
Đọc output/{BATCH_ID}/{BATCH_ID}.json (items có photoPrompt)

Viết CAPTION cho {IDS} (nửa đầu).
- 1000–1200 ký tự mỗi caption (đếm ký tự)
- 3 đoạn + blank line + CTA (MORE / YES / NEXT)
- Đoạn 2: 1 visual detail từ photo prompt
- Không spoil twist
- openingStyle đúng plan

Cập nhật JSON — chỉ caption + status.caption=true.
In bảng verify: id | char count | opening style | CTA
DỪNG sau Phase 2A.
```

**Phase 2B** — second half.

---

### Phase 3 — Full Stories (2 items)

```
Dùng skill storywriting — Phase 3 ONLY.

Đọc references/full-story-methodology.md
Đọc output/{BATCH_ID}/{BATCH_ID}.json

Viết FULL STORY cho {ID_A} và {ID_B} ONLY.
- 6000–8000 ký tự mỗi bài (đếm ký tự)
- Mở đầu khớp caption — reader cảm continuity
- 4 acts: Hook → Pressure → Turn → Payoff
- Twist + consequence antagonist + final line cụ thể
- Character Lock nhất quán
- Không copy CTA Facebook vào story

Cập nhật JSON — chỉ 2 items này + status.story=true.
In verify: id | char count | first 80 chars of opening
DỪNG. Không viết story khác.
```

Repeat for each pair until all items done.

---

### Phase 4 — Export TXT

```
Dùng skill storywriting — Phase 4 ONLY.

Đọc output/{BATCH_ID}/{BATCH_ID}.json
Verify mọi item có photoPrompt, caption, fullStory đầy đủ.

Xuất output/{BATCH_ID}/{BATCH_ID}-package.txt theo format batch-mode.md.
- KHÔNG sửa nội dung creative — chỉ assemble
- Ghi char count caption và full story trong header mỗi item
- Chạy output checklist trong SKILL.md

Optional: cũng xuất -photos.txt, -captions.txt, -stories.txt
Hoặc chạy: node scripts/json-to-txt.js output/{BATCH_ID}/{BATCH_ID}.json
```

---

### Fix single item

```
Dùng skill storywriting — FIX ONLY.

Batch: {BATCH_ID} | Item: {ID_A}
Đọc output/{BATCH_ID}/{BATCH_ID}.json

Chỉ sửa {ID_A}.fullStory — hiện {CURRENT} chars, cần 6500–7200 chars.
Giữ nguyên photoPrompt, caption, characterBible.
Không đụng items khác.
Sau khi sửa: cập nhật JSON + regenerate {BATCH_ID}-package.txt cho item đó hoặc cả file.
```

---

## Phase schedule for 10 items

| Session | Phase | Items |
|---------|-------|-------|
| 1 | 0 Plan | C041–C050 |
| 2 | 1A Photo | C041–C045 |
| 3 | 1B Photo | C046–C050 |
| 4 | 2A Caption | C041–C045 |
| 5 | 2B Caption | C046–C050 |
| 6 | 3 Story | C041–C042 |
| 7 | 3 Story | C043–C044 |
| 8 | 3 Story | C045–C046 |
| 9 | 3 Story | C047–C048 |
| 10 | 3 Story | C049–C050 |
| 11 | 4 Export | assemble TXT |

Total: **11 short sessions** vs 1 session that breaks.

---

## Single concept (1 item)

For 1 concept only, run Phase 0–3 in one session is OK (total ~9k chars output).
Still use JSON + export TXT. Skip splitting into 5+5.

Prompt:

```
Dùng skill storywriting — single item {ID}.
Phase 0→3 trong 1 session (chỉ 1 item).
Output: output/{BATCH_ID}/{BATCH_ID}.json + {BATCH_ID}-package.txt
KHÔNG HTML.
```
