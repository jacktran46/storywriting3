const fs = require('fs');
const path = 'C:/Users/xuros/Downloads/storywriting/output/batch-05/batch-05.json';

const stories = {
  C053: `Rick Holloway's voice cracked on his next insult, and for half a second the Silver Creek Ranch auction barn went quieter than noon dust.

"—and tell your lawyer friend out there he can read paperwork after I finish with—"

"After you finish with what, Rick?" The man in the rumpled suit had already crossed the threshold, leather deed folder tucked under one arm like something that had waited years for this exact slatted light. His boots were not clean. Neither was his patience. "You're standing in a criminal fraud conversation in front of three witnesses with Texas plates. Choose the next sentence carefully."

Caleb Dunn stayed against the hay bale where Rick had shoved him, canvas shirt damp with sweat, gray beard catching dust. His left leg bent slightly from the old injury that had never cost him his land — only cost him his son's respect when greed outgrew gratitude. The ornate belt buckle at his waist caught another blade of sun through the barn slats: the original Silver Creek brand, silver worn smooth by decades of work, not the reproduction buckle Rick wore like a costume.

The buyers near the door did not laugh. They had come to Bozeman looking for distressed acreage and honest water rights. They were not stupid. They were merely late to the real story.

Twenty minutes earlier, Rick had been winning the morning he wanted.

He moved through the auction barn in his cowboy hat and leather vest with the confidence of a man who believed paperwork made morality. Three out-of-state buyers in clean hats trailed him between horse stalls and hay racks while he narrated improvements he had never paid for and fences Caleb had rebuilt after the winter kill three years back. Rick liked audiences. He liked proving who belonged on Silver Creek floorboards.

Caleb belonged there longer than Rick had been alive.

He had mucked stalls that morning before dawn, limp and all, because habit outlasted ownership on paper. When Rick spotted mud near the buyers' boots — Caleb's boot, returning from the north pasture gate — Rick saw opportunity. Humiliation in front of money men was currency Rick had spent his whole management career collecting.

"Get your filthy boots off my buyers' floor!"

The shove came hard enough to steal breath but not balance. Caleb absorbed it the way old timber absorbs weight — silent, structural, still standing. Rick jabbed a finger at the buckle as if it were stolen décor.

"That thing's not yours either."

"It was my father's," Caleb said.

"Your father's dead."

"Which is why your employer forged his signature."

Rick laughed too loud. One buyer's smile died mid-rise.

The county lawyer — Eli Paterson — had been sitting in a pickup outside since 6am waiting for Caleb's signal. Caleb had not wanted spectacle. He had wanted his ranch back without another court delay. Rick's performance gave him no choice but to walk in mid-shove.

Paterson opened the deed folder on a hay bale, flattening pages with a hand that did not shake. "Power of attorney recorded eighteen months ago. Notarized in Gallatin County. Signature match disputed by three independent experts. Forged after Caleb Dunn's knee surgery, while he was sedated in St. Vincent's Billings and his son, Derek, cleaned out the operating accounts."

Rick's color changed. "Derek runs operations. That's legal."

"Derek stole operations," Paterson said. "And paid you to keep the old man off the buyer list."

The buyers stepped closer without being invited. One of them, older, squinted at Caleb's buckle in the dust light and pulled out his phone — not for spectacle, for a historical registry app he used to verify provenance on heritage cattle brands. The screen loaded a black-and-white archive photo from 1952: same curled S hook through creek line, same notch pattern worn into a younger man's belt at a county fair.

"That's the original Silver Creek mark," the buyer said slowly. "Not registered to Holloway Management."

Rick reached for the folder. Paterson slapped his wrist with the folder edge — not hard, but enough to make law feel physical. "Touch that again and I add assault to the complaint already filed this morning."

Caleb finally straightened fully off the hay bale. The limp was real. So was the deed.

"Derek told me you signed," Rick said, voice smaller now. "Said you wanted out."

"I signed a surgical consent form," Caleb replied. "He translated that into selling my cattle, my water rights, and my name to men who never met me."

One buyer removed his hat. The gesture spread without discussion — respect arriving late but sincerely. Rick looked at the hat in the buyer's hands and understood his performance had just priced him out of every future contract in three states.

Paterson turned a page. "Temporary restraining order effective immediately. Derek Dunn barred from financial transactions on Silver Creek property pending criminal review. Rick Holloway terminated as acting manager by court order attached here."

Rick's vest suddenly looked too new for the barn. "You can't fire me in front of—"

"I can," Caleb said, "because I never hired you. My son did, with my forged hand."

The barn door opened again. Derek Dunn came in fast — forty-one, city jacket over ranch boots, phone already recording as if video could rewrite paper. He stopped when he saw the folder, the buyers' faces, and his father's buckle catching slatted light like evidence that refused to stay buried.

"Dad, this is a misunderstanding."

Caleb looked at his son the way a man looks at weather he can no longer predict. "You sold the north pasture while I was under anesthesia. You told the bank I was incompetent. You paid Rick to keep me limping in the shadows so buyers would think the ranch was distressed and cheap."

"I was protecting the operation."

"You were protecting your theft."

Derek's phone lowered. Paterson held out a second document. "Sheriff's office is en route for interview. I suggest you stay."

The Texas buyers did not bid that afternoon. They asked for water maps Caleb remembered by heart and left their cards on an honest hay bale. One wrote on the back: Call if you run heritage steers again. We pay for provenance.

Rick gathered his hat without being told. Caleb did not watch him go. He watched the brand on his buckle instead — the mark his grandfather had filed in county records when Bozeman was still arguing about railroad lines.

By evening, Caleb stood on the porch he had built with his own hands while Paterson filed the final reinstatement papers. Derek's truck was gone from the drive. The management office keys lay on the kitchen table where Rick used to hang charts of cattle he never fed.

Three weeks later, Silver Creek held an open gate day for neighbors instead of an auction for strangers. Caleb walked the north fence line with his limp and a thermos, stopping where Derek had posted For Sale signs he had never authorized. The signs came down one by one.

Rick Holloway applied for work in Wyoming under a reference Caleb refused to give. Derek hired a defense attorney and lost the ranch accounts before he lost his freedom. Buyers who had watched the barn that noon sent letters apologizing for almost buying stolen ground.

Caleb kept the original buckle on his belt, silver worn smooth, catching noon light through barn slats whenever he passed through the door he never should have lost and finally, in front of witnesses who knew how to read a brand, took back.`,

  C054: `My fingers loosened before my pride allowed them to, and Isabel Reyes did not pull away first — I did.

That should have told me everything. Accusers who are right do not feel their grip go soft when the accused whispers. They tighten. They perform certainty for the foyer, for the arriving guests in cashmere, for the photographers scheduled at two-thirty sharp on the Whitfield marble. I had crossed the foyer in my emerald dress to expose a thief, and Isabel, fifty-two, black uniform, stood with her chin lifted like a woman who had rehearsed this scene longer than I had.

"You are holding the wrong woman," she said again, quieter.

The silver clasp at her throat caught coastal light through the tall Newport windows — too precise for costume, too familiar for my comfort. I had never seen it in a catalog. I had seen something like it in a framed photograph Henry kept locked in his study, the one he would not discuss: his first wife, Catherine, holding an infant on a sailboat deck the summer before the accident.

Guests froze near the entry table with coats half-off. Perfume and salt air mixed in the hall. From the curved staircase, Henry Whitfield watched without speaking, cane tight in one hand, face unreadable at seventy-eight.

Ten minutes earlier, I had been certain.

The pearl necklace was missing from my dressing room — not the modest strand I wore to board meetings, but the Whitfield heirloom Henry's mother had worn to every Newport charity season since 1962. I had laid it on the velvet tray at noon before hair and makeup. At one-forty, the tray was empty and Isabel had been the only staff member on the second floor.

It fit the story I wanted. The housekeeper with the quiet eyes and the old-country accent taking what the new Mrs. Whitfield had earned by surviving this family's moods. Henry's second marriage had never been fully accepted by the old guard. I had learned to convert their skepticism into authority. Accuse cleanly. Win publicly.

Isabel had flinched when I entered the staff corridor. That flinch felt like guilt.

I grabbed her wrist in the foyer hard enough to make the clasp flash. "Where is it?"

"I am not wearing your pearls," Isabel said.

"That clasp isn't yours."

"No," she agreed. "It is not."

Her calm unnerved me more than denial would have. I shook her wrist once, a mistake I felt immediately in the silence of arriving guests. One woman in pearls of her own stepped back as if proximity might stain.

Henry descended one stair at a time. The cane tapped marble with a rhythm I had heard at a thousand galas, but never with this weight.

"Vanessa," he said. Not a shout. Worse — a name spoken like a door closing.

"Henry, she stole—"

"Show me the clasp."

Isabel did not resist. She turned her throat slightly, the way witnesses turn toward light. Henry leaned in, spectacles low on his nose, and went still in the particular way men go still when memory returns with engineering detail.

"This mechanism," he whispered. "I designed this clasp myself. Catherine wanted something a child could not unfasten on a boat deck."

The foyer temperature seemed to drop. My emerald dress suddenly felt like a costume.

"You designed it for Catherine," I said, because if I named the first wife aloud I could keep control of the narrative. "Then it should be in the vault, not on—"

"Not on her," Henry finished. He looked at Isabel. "On our daughter."

Isabel closed her eyes once. When she opened them, there were tears she did not wipe.

"No," I heard myself say. "Margaret died in the boating accident. Everyone knows—"

"Everyone knows what I signed after Catherine drowned," Henry said. "Death certificate for Margaret issued when we never recovered a body. I was grief-mad and persuaded by lawyers who benefited from a clean estate. I have regretted that signature for thirty-one years."

The photographers had not arrived yet. Thank God for small mercies that were no longer mine.

Isabel's voice was steady. "My name was Margaret Whitfield until I was twelve. After the storm, a fishing crew pulled me from debris near Block Island with a head injury and no identification. Catherine's necklace was still on my neck. The clasp held."

Henry's hand trembled on the cane. "I searched."

"You searched the water," Isabel said. "Not the hospitals that listed me as Jane Doe."

Guests murmured. I felt each murmur like a verdict I had asked for.

Henry reached toward the clasp but did not touch it without permission. Isabel nodded once. His fingers found the mechanism — a tiny lateral slide he had invented in a workshop, a lock against waves and careless hands. He opened it with muscle memory and closed it again, tears now on his face without shame.

"Margaret," he said.

"I kept the name Isabel," she replied. "The nun who raised me in Providence until I was eighteen. I came back to Newport last year when I saw your foundation luncheon listed in the paper. I did not come to take anything. I came to see whether you were still alive to tell."

The accusation I had made in front of witnesses reassembled itself in my throat as ash.

"The necklace in your dressing room," Isabel said, looking at me now without victory — worse, with pity. "It is on the east hall table where you left it after trying it with the emerald earrings. I passed it on my way down."

My assistant, pale near the entry, nodded once, confirming what I had been too angry to verify.

I had not lost pearls. I had lost judgment in public.

Henry turned to the guests with the authority of a man who had built half the harbor. "Luncheon is canceled. Margaret — Isabel — will be staying in the east wing. Vanessa, you will release her wrist, and you will not speak for her again in this house."

My fingers were already empty. Pride arrived late and useless.

I stepped back. Isabel did not rub the marks my grip had left. She adjusted the clasp instead, the custom mechanism catching light like a small machine built for survival.

In the study an hour later, Henry spread old newspaper clippings across the desk — search boats, memorial service, estate transfers finalized six months after the storm. Second marriage announcements followed. My photograph among them, smiling beside a man who had buried a daughter he never stopped searching for in the wrong records.

"I married again because I was told to heal," Henry said. "You married me because this house opens doors. Neither fact erases the other. But today you accused my living daughter of theft to protect a status you had not earned."

The words were quiet. They landed anyway.

Isabel — Margaret — sat in Catherine's old chair by the window, hands folded, necklace at her throat. She did not ask me to leave. She did not need to. The house had already rearranged itself around her return.

Over the following weeks, the charity board sent polite inquiries. I sent resigned answers. Henry filed amended records with the county and placed Isabel's name where it should have lived since childhood. The second Mrs. Whitfield's seat at the harbor gala remained empty by my choice, not his command.

On a Sunday when coastal light lay soft on the marble again, I watched from the library doorway as Henry showed Isabel the sailboat photograph — Catherine laughing, infant Margaret gripping the same clasp now restored to its rightful throat.

Isabel saw me watching. She did not invite me closer. She did not ban me either. She simply turned back to her father, and the clasp caught the window once more — precise, custom, impossible to fake, holding fast through everything that should have broken it.

I closed the library door quietly and left them to a reunion I had almost stolen because I wanted a villain more than I wanted the truth.`,
};

const batch = JSON.parse(fs.readFileSync(path, 'utf8'));
for (const [id, fullStory] of Object.entries(stories)) {
  const len = fullStory.length;
  const item = batch.items.find((i) => i.id === id);
  item.fullStory = fullStory;
  item.status.story = true;
  console.log(id, len, len >= 6000 && len <= 8000 ? 'OK' : 'RANGE');
}
fs.writeFileSync(path, JSON.stringify(batch, null, 2) + '\n');
